The Gradle Wrapper JAR is normally generated/provided by Gradle/Android IDE. If your IDE asks to create/download the wrapper, accept the default Gradle 8.7 option.
