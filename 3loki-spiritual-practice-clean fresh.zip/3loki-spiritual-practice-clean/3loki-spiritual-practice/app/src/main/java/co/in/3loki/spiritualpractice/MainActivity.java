package co.in.3loki.spiritualpractice;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 80, 48, 48);

        TextView title = new TextView(this);
        title.setText("3loki.co.in");
        title.setTextSize(32);
        title.setGravity(17);

        TextView subtitle = new TextView(this);
        subtitle.setText("\nSpiritual Practice\n\nWelcome to 3loki — a space for spiritual practice, teachings and community.");
        subtitle.setTextSize(18);
        subtitle.setGravity(17);

        Button practice = new Button(this);
        practice.setText("START SPIRITUAL PRACTICE");
        practice.setOnClickListener(v -> subtitle.setText(
                "\nYour spiritual practice begins with awareness.\n\nBreathe • Meditate • Practice • Grow"
        ));

        layout.addView(title);
        layout.addView(subtitle);
        layout.addView(practice);

        setContentView(layout);
    }
}
