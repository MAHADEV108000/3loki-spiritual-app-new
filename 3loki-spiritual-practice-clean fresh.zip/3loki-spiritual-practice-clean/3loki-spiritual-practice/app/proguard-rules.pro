# 3loki Spiritual Practice - no custom ProGuard rules required for the starter build.
